//// static/js/renderResults.js
//
///**
// * Render the grouped results
// * @param {Array} data - The array of groups from API
// */
//export function renderResults(data) {
//    const container = document.getElementById('resultsContainer');
//    container.innerHTML = '';
//
//    if (!data || data.length === 0) {
//        container.innerHTML = `
//            <div class="col-12">
//                <div class="alert alert-warning">No results found</div>
//            </div>
//        `;
//        return;
//    }
//
//    data.forEach((group, index) => {
//        const groupKey = group.Seller || group.Isbn || 'Unknown';
//        const groupId = `group-${index}`;
//
//        const groupCard = document.createElement('div');
//        groupCard.className = 'col-12';
//
//        groupCard.innerHTML = `
//            <div class="card mb-3">
//
//                <!-- Clickable header -->
//                <div
//                    class="card-header bg-light d-flex justify-content-between align-items-center cursor-pointer"
//                    data-group-id="${groupId}"
//                >
//                    <div>
//                        <h5 class="mb-1">${groupKey}</h5>
//                        <small class="text-muted">
//                            Available: ${group['Available Books']} |
//                            Sold: ${group['Books Sold']} |
//                            Rotation: ${group['Average Rotation (%)']}
//                        </small>
//                    </div>
//                    <span class="toggle-icon">+</span>
//                </div>
//
//                <!-- Collapsible body (hidden initially) -->
//                <div
//                    id="${groupId}"
//                    class="card-body d-none"
//                    data-rendered="false"
//                >
//
//                    <div class="row mb-2">
//                    <strong>List of Available Books: ${group['Available Books']}</strong>
//                        <div class="col-md-4">
//                            <strong>Avg Price:</strong> ${group['Average Price']}
//                        </div>
//                        <div class="col-md-4">
//                            <strong>Min Price:</strong> ${group['Minimum Price']}
//                        </div>
//                        <div class="col-md-4">
//                            <strong>Max Price:</strong> ${group['Maximum Price']}
//                        </div>
//                    </div>
//
//                    <div class="list-group"></div>
//                </div>
//
//            </div>
//        `;
//
//        container.appendChild(groupCard);
//
//        // Attach click handler for collapse toggle + lazy render
//        const header = groupCard.querySelector('.card-header');
//        header.addEventListener('click', () => toggleGroup(group, groupId, header));
//    });
//}
//
///**
// * Toggle a group's items visibility
// * Lazy renders items on first click
// */
//function toggleGroup(group, groupId, header) {
//    const body = document.getElementById(groupId);
//    const listGroup = body.querySelector('.list-group');
//    const icon = header.querySelector('.toggle-icon');
//
//    // Lazy render (first time only)
//    if (body.dataset.rendered === 'false') {
//        listGroup.innerHTML = renderItems(group.results);
//        body.dataset.rendered = 'true';
//    }
//
//    body.classList.toggle('d-none');
//    icon.textContent = body.classList.contains('d-none') ? '+' : '−';
//}
//
///**
// * Render individual items for a group
// */
// function renderItems(items) {
//    if (!items || items.length === 0) {
//        return `<div class="text-muted">No available books</div>`;
//    }
//
//    return items.map((item, index) => `
//        <a href="${item.url}" target="_blank" rel="noopener noreferrer"
//        class="list-group-item list-group-item-action d-flex align-items-center gap-3 text-decoration-none">
//
//            <!-- Item number -->
//            <div>
//                ${index + 1}.
//            </div>
//
//            <!-- Book image -->
//            <img src="${item.image || '/static/images/no-book.png'}" alt="${item.name || 'Book image'}"
//            style="width: 50px; height: 70px; object-fit: cover;" class="rounded border">
//
//            <!-- Book info -->
//            <div class="flex-grow-1">
//                <strong class="text-dark">${item.name || 'Untitled'}</strong><br>
//                <small class="text-muted"> ${item.seller} | ${item.condition} | ${item.isbn} </small><br>
//                <small class="text-muted">
//                Scraped Date: ${item.first_seen || 'N/A'}  |  Last seen: ${item.date_scraped || 'N/A'}
//                </small>
//            </div>
//
//            <!-- Price -->
//            <div class="text-end"> <span class="fw-bold text-dark"> ${item.price}</span> </div>
//        </a>
//    `).join('');
//}
//================================ After adding interested flag ==================================

// static/js/renderResults.js

/**
 * Render the grouped results
 * @param {Array} data - The array of groups from API
 */
export function renderResults(data) {
    const container = document.getElementById('resultsContainer');
    container.innerHTML = '';

    if (!data || data.length === 0) {
        container.innerHTML = `
            <div class="col-12">
                <div class="alert alert-warning">No results found</div>
            </div>
        `;
        return;
    }

    data.forEach((group, index) => {
        const groupKey = group.Seller || group.Isbn || 'Unknown';
        const groupId = `group-${index}`;

        const groupCard = document.createElement('div');
        groupCard.className = 'col-12';

        groupCard.innerHTML = `
            <div class="card mb-3">

                <!-- Clickable header -->
                <div
                    class="card-header bg-light d-flex justify-content-between align-items-center cursor-pointer"
                    data-group-id="${groupId}"
                >
                    <div>
                        <h5 class="mb-1">${groupKey}</h5>
                        <small class="text-muted">
                            Available: ${group['Available Books']} |
                            Sold: ${group['Books Sold']} |
                            Rotation: ${group['Average Rotation (%)']}
                        </small>
                    </div>
                    <span class="toggle-icon">+</span>
                </div>

                <!-- Collapsible body (hidden initially) -->
                <div
                    id="${groupId}"
                    class="card-body d-none"
                    data-rendered="false"
                >

                    <div class="row mb-2">
                    <strong>List of Available Books: ${group['Available Books']}</strong>
                        <div class="col-md-4">
                            <strong>Avg Price:</strong> ${group['Average Price']}
                        </div>
                        <div class="col-md-4">
                            <strong>Min Price:</strong> ${group['Minimum Price']}
                        </div>
                        <div class="col-md-4">
                            <strong>Max Price:</strong> ${group['Maximum Price']}
                        </div>
                    </div>

                    <div class="list-group"></div>
                </div>

            </div>
        `;

        container.appendChild(groupCard);

        const header = groupCard.querySelector('.card-header');
        const body = document.getElementById(groupId);
        const icon = header.querySelector('.toggle-icon');

        // Attach click handler that updates openGroups
        header.addEventListener('click', () => {
            const wasHidden = body.classList.contains('d-none');
            toggleGroup(group, groupId, header); // this toggles visibility and lazy-renders
            const nowHidden = body.classList.contains('d-none');
            if (wasHidden !== nowHidden) {
                if (nowHidden) {
                    window.openGroups.delete(groupKey);
                } else {
                    window.openGroups.add(groupKey);
                }
            }
        });

        // If this group was open before re‑render, expand it now
        if (window.openGroups && window.openGroups.has(groupKey)) {
            toggleGroup(group, groupId, header); // expands and renders items
        }
    });
}

/**
 * Toggle a group's items visibility
 * Lazy renders items on first click
 */
function toggleGroup(group, groupId, header) {
    const body = document.getElementById(groupId);
    const listGroup = body.querySelector('.list-group');
    const icon = header.querySelector('.toggle-icon');

    // Lazy render (first time only)
    if (body.dataset.rendered === 'false') {
        listGroup.innerHTML = renderItems(group.results);
        body.dataset.rendered = 'true';
    }

    body.classList.toggle('d-none');
    icon.textContent = body.classList.contains('d-none') ? '+' : '−';
}

/**
 * Render individual items for a group
 */
function renderItems(items) {
    if (!items || items.length === 0) {
        return `<div class="text-muted">No available books</div>`;
    }

    // Read current interested set
    const interestedSet = new Set(JSON.parse(localStorage.getItem('interestedBooks') || '[]'));

    return items.map((item, index) => {
        const isInterested = interestedSet.has(item.url);
        return `
            <a href="${item.url}" target="_blank" rel="noopener noreferrer"
               class="list-group-item list-group-item-action d-flex align-items-center gap-3 text-decoration-none">

                <!-- Star (clickable) with class for styling -->
                <span class="interested-star ${isInterested ? 'filled' : ''}" data-url="${item.url}">
                    ${isInterested ? '★' : '☆'}
                </span>

                <!-- Item number -->
                <div>${index + 1}.</div>

                <!-- Book image -->
                <img src="${item.image || '/static/images/no-book.png'}" alt="${item.name || 'Book image'}"
                     style="width: 50px; height: 70px; object-fit: cover;" class="rounded border">

                <!-- Book info -->
                <div class="flex-grow-1">
                    <strong class="text-dark">${item.name || 'Untitled'}</strong><br>
                    <small class="text-muted"> ${item.seller} | ${item.condition} | ${item.isbn} </small><br>
                    <small class="text-muted">
                        Scraped Date: ${item.first_seen || 'N/A'}  |  Last seen: ${item.date_scraped || 'N/A'}
                    </small>
                </div>

                <!-- Price -->
                <div class="text-end">
                    <span class="fw-bold text-dark">${item.price}</span>
                </div>
            </a>
        `;
    }).join('');
}